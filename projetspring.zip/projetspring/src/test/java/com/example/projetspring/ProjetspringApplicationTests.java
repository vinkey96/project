package com.example.projetspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetspringApplicationTests {

    @Test
    void contextLoads() {
    }

}
